import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  get nombre() {
    return this.registrationForm.get('nombre');
  
  }

  get password() {
    return this.registrationForm.get('password');
  
  }

  public errorMessages = {
    nombre: [
      {type: 'requiered', message: 'Nombre es requerido' },
      {type: 'maxlenght', message: 'El nombre no puede contener mas de 10 caracteres'} 
    ],
    password: [
      {type: 'requiered', message: 'Nombre es requerido' },
      {type: 'maxlenght', message: 'El nombre no puede contener mas de 10 caracteres'} 
    ]
  };
  
  registrationForm = this.formBuilder.group({
      nombre: ['', [Validators.required, Validators.maxLength(10)]],
      password: ['', [Validators.required, Validators.maxLength(10)]]
  });

  constructor(private formBuilder: FormBuilder) {}

  public submit() {
    console.log(this.registrationForm.value);
  }

}
